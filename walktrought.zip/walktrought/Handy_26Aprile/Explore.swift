//
//  Explore.swift
//  Handy_26Aprile
//
//  Created by Maurizio Lucci on 15/06/17.
//  Copyright © 2017 Federico Cattaneo. All rights reserved.
//

import Foundation

struct Explore {
    let title: String
    let distance: String
    let price: String
    let profile: String
    let imageName: String
}
