//
//  page.swift
//  Handy_26Aprile
//
//  Created by Federico Cattaneo on 27/04/2017.
//  Copyright © 2017 Federico Cattaneo. All rights reserved.
//

import Foundation

struct Page {
    let title: String
    let message: String
    let imageName: String
}
