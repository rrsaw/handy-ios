
import UIKit
import Alamofire
var exploreCell = ExploreCell()

class ExploreController: UIViewController, UICollectionViewDelegateFlowLayout, UICollectionViewDelegate, UICollectionViewDataSource {
    
    fileprivate var jsonData: Array<Dictionary<String, AnyObject>> = []
    let tableData: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        let collection = UICollectionView(frame: CGRect(x: 0, y: 0, width: 375, height: 400), collectionViewLayout: layout)
        collection.backgroundColor = .gray
        return collection
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
//        view.backgroundColor = .white
//        collectionView?.register(ExploreCell.self, forCellWithReuseIdentifier: "cellId")
        navigationItem.title = "Explore"
        navigationController?.navigationBar.isTranslucent = true
        
        tableData.delegate = self
        tableData.dataSource = self
        tableData.register(ExploreCell.self, forCellWithReuseIdentifier: "cellId")
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        
        Alamofire.request("http://handyshare.me/api/v1/items").responseJSON { response in
            if let JSON = response.result.value
            {
                UIApplication.shared.isNetworkActivityIndicatorVisible = false
                self.jsonData = JSON as! Array<Dictionary<String, AnyObject>>
            }
        }
    }
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
       return jsonData.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
//        if indexPath.item == jsonData.count {
//            
//        }
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cellId", for: indexPath) as! ExploreCell
        cell.titleItem.text = self.jsonData[indexPath.row]["name"] as? String

        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: view.frame.width, height: 140)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}


extension UIView {
    func addConstraintsWithFormat(format: String, views: UIView...){
        var viewsDictionary = [String: UIView]()
        for (index, view) in views.enumerated(){
            let key = "v\(index)"
            view.translatesAutoresizingMaskIntoConstraints = false
            viewsDictionary[key] = view
        }
        addConstraints(NSLayoutConstraint.constraints(withVisualFormat:format, options: NSLayoutFormatOptions(), metrics: nil, views: viewsDictionary))
    }
}
